package testing;

import static org.junit.jupiter.api.Assertions.*;
import grading.*;
import org.junit.jupiter.api.Test;

class AbstractGradeTest
{

  @Test
  void test()
  {
    
  }

}
