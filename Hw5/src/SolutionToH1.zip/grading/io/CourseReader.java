package grading.io;

import java.io.BufferedReader;

import grading.*;

/**
 * CS 345 HW4 CourseReader.
 * 
 * @author Joshua Steffen
 * @version 2/10/22
 */
public class CourseReader
{

  /**
   * Reads the next category.
   * 
   * @param in
   *          the reader for input
   * @param size
   *          the size
   * @param key
   *          the key
   * @param filter
   *          the filter
   * @return information about the next category
   */
  public static Category readCategory(final BufferedReader in, final int size, final String key,
      final Filter filter)
  {
    return null;
  }

  /**
   * Return a Course object that contains size different Category objects.
   * 
   * @param in
   *          takes input
   * @param size
   *          the size
   * @return a Course object that contains size different Category objects
   */
  public static Course readCourse(final BufferedReader in, final int size)
  {
    return null;
  }
}
